import DashboardAdmin from "./dashboardAdmin";
import Categories from "./categories";
import Products from "./products";
import Orders from "./orders";

export { DashboardAdmin, Categories, Products, Orders };
